"""Trusted placeholder Lambda handler fixture (Phase 2, Batch 18).

This file exists solely so terraform plan has a real local deployment
package to hash and reference — it is never invoked by any test or by
production code, and it is unrelated to the handler string a caller
configures on LambdaResourceSpec (this project never calls
terraform apply, so the two never need to match). Do not treat this as
example application code.
"""


def handler(event, context):
    return {"statusCode": 200, "body": "placeholder"}
